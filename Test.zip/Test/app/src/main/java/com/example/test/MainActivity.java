package com.example.test;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import com.example.test.BDHealper;

public class MainActivity extends AppCompatActivity {

    BDHealper dbHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new BDHealper(this, "mybd", null, 1);
        SQLiteDatabase db= dbHelper.getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put("field1", "field1 text");
        cv.put("field2", "field2 text");
        long rowID = db.insert("mytable", null, cv);

        String[] columns = new String[]{"field1", "sum(field2) as field"};
        String selection = "field1 > ?";
        String having = "sum(field3) > 25";

        Cursor cursor= db.query("mytable", columns, selection, null,
                null, having, null);

        cursor.moveToFirst();

        int idColIndex = cursor.getColumnIndex("id");
        int field1ColIIndex = cursor.getColumnIndex("field1");
        int field2ColIIndex = cursor.getColumnIndex("field2");

        do{
            int id = cursor.getInt(idColIndex);
            String field1 = cursor.getString(field1ColIIndex);
            String field2 = cursor.getString(field2ColIIndex);
        }while (cursor.moveToNext());

        cursor.close();
    }
}
